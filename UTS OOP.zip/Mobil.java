public  class Mobil {
    static String warna ="Biru";
    static String merk ="Ford";
    protected static String pa ="AS"; //pabrik asal
    private static String kecmobil="200km/jam";


    public static void maju() {
        System.out.println("Mobil "+merk+" Berwarna "+warna+" Bergerak maju");
    }

    public static void mundur(){
        System.out.println("Mobil "+merk+" Berwarna "+warna+" Bergerak mundur");
    }

    protected static void pabrikasal(){
        System.out.println(merk+" Berasal dari "+pa);
    }
    public static void kecepatanmob(){
        System.out.println("Maximal kecepatan Mobil mencapai : "+ kecmobil);
    }  //masih bisa dipanggil pada class main meskipun property private




}
