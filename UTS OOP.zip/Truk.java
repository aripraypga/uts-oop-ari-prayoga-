public class Truk {
    static String warna ="Hijau";
    static String merk ="Mitubishi";
    protected static String pa ="Jepang";    //pabrik asal
    private static String kectruk ="205km/jam";


    public static void majutruk(){
        System.out.println("Truk "+merk+" berwarna"+warna+" bergerak maju");
    }

    public static void mundurtruk(){
        System.out.println("Truk "+merk+" berwarna"+warna+" bergerak mundur");
    }
    protected static void pabrikasal(){
        System.out.println("Truk "+merk+" Berasal dari "+pa);
    }
    public static void kecepatantruk(){
        System.out.println("Maximal kecepatan truk mencapai : " +kecmotor);
    }
}
